import { useState, useEffect } from 'react'
import { getProduitsByCategorie, type Produit } from './services/airtable'
import Panier from './components/Panier'
import './App.css'

function App() {
  const [produits, setProduits] = useState<Produit[]>([])
  const [categorie, setCategorie] = useState<string>('Goutte')

  useEffect(() => {
    const chargerProduits = async () => {
      const produits = await getProduitsByCategorie(categorie)
      setProduits(produits)
    }
    chargerProduits()
  }, [categorie])

  return (
    <div className="min-h-screen p-8">
      <header className="mb-8">
        <h1 className="text-4xl font-bold text-primary">Devis en ligne - Drapeaux</h1>
      </header>

      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Choisissez votre type de drapeau</h2>
        <div className="flex gap-4">
          {['Goutte', 'Plume', 'Droit'].map((type) => (
            <button
              key={type}
              onClick={() => setCategorie(type)}
              className={`px-4 py-2 rounded-xl ${
                categorie === type
                  ? 'bg-accent text-white'
                  : 'bg-white text-primary hover:bg-gray-100'
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {produits.map((produit) => (
          <div
            key={produit.id}
            className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow"
          >
            {produit.fields.Photo?.[0] && (
              <img
                src={produit.fields.Photo[0].url}
                alt={produit.fields['Nom complet']}
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
            )}
            <h3 className="text-xl font-semibold mb-2">{produit.fields['Nom complet']}</h3>
            <p className="text-gray-600 mb-4">{produit.fields.Description}</p>
            <div className="flex justify-between items-center">
              <span className="text-lg font-bold text-accent">
                {produit.fields['Prix TTC (€)']}€
              </span>
              <button 
                className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-opacity-90"
                onClick={() => {
                  const event = new CustomEvent('ajouterProduit', { detail: produit })
                  window.dispatchEvent(event)
                }}
              >
                Ajouter au devis
              </button>
            </div>
          </div>
        ))}
      </div>

      <Panier />
    </div>
  )
}

export default App
