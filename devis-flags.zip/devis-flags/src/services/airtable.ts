// (Suppression de l'import Airtable)

const apiKey = import.meta.env.VITE_AIRTABLE_API_KEY;
const baseId = import.meta.env.VITE_AIRTABLE_BASE_ID;

if (!apiKey || !baseId) {
  console.error('❌ Variable d\'environnement VITE_AIRTABLE_API_KEY ou VITE_AIRTABLE_BASE_ID manquante !');
  throw new Error('Configuration manquante : merci de renseigner VITE_AIRTABLE_API_KEY et VITE_AIRTABLE_BASE_ID dans Netlify.');
}

const AIRTABLE_API_URL = `https://api.airtable.com/v1/bases/${baseId}/tables`;

// (Suppression de la déclaration de base et de l'objet tables)

export interface Produit {
  id: string;
  fields: {
    Catégorie: 'Goutte' | 'Plume' | 'Droit' | 'ACCESSOIRE';
    Format: 'XS' | 'S' | 'M' | 'L' | 'XL' | 'XXL' | 'XXXL' | '';
    'Nom complet': string;
    Dimensions: string;
    Description: string;
    'Prix TTC (€)': number;
    'Poids (kg)': number;
    Fournisseur: string[];
    'Ref fournisseur': string;
    'Prix achat (€)': number;
    Photo: { url: string }[];
  };
}

export interface Devis {
  id: string;
  fields: {
    'N° de devis': string;
    Jeton: string;
    Nom: string;
    Prénom: string;
    Société: string;
    Email: string;
    Téléphone: string;
    Adresse: string;
    'Total TTC (€)': number;
    PDF: { url: string }[];
    Statut: 'nouveau' | 'rouvert' | 'téléchargé';
    Ouvertures: number;
  };
}

const fetchAirtable = async (table: string, params: string = '') => {
  const url = `${AIRTABLE_API_URL}/${table}/records${params}`;
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
  });
  if (!res.ok) {
    throw new Error(`Erreur API Airtable (${table}): ${res.status}`);
  }
  return res.json();
};

const getProduits = async (): Promise<any[]> => {
  const res = await fetch('/.netlify/functions/getProduits');
  if (!res.ok) {
    throw new Error('Erreur lors de la récupération des produits');
  }
  return await res.json();
};

export const getProduitsByCategorie = async (categorie: string): Promise<Produit[]> => {
  // Airtable API v1 ne supporte pas filterByFormula, il faut filtrer côté client
  const data = await fetchAirtable('Produits');
  return (data.records as Produit[]).filter(
    (p) => p.fields.Catégorie === categorie
  );
};

export const getFournisseurs = async (): Promise<any[]> => {
  const data = await fetchAirtable('Fournisseurs');
  return data.records;
};

export const getDevis = async (): Promise<any[]> => {
  const data = await fetchAirtable('Devis');
  return data.records;
};

export const getLignesDeDevis = async (): Promise<any[]> => {
  const data = await fetchAirtable('Lignes de devis');
  return data.records;
};

// Pour la création, il faut utiliser la méthode POST de l'API v1
export const createDevis = async (fields: any) => {
  const url = `${AIRTABLE_API_URL}/Devis/records`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ records: [{ fields }] }),
  });
  if (!res.ok) {
    throw new Error('Erreur lors de la création du devis');
  }
  const data = await res.json();
  return data.records[0];
};

export const updateDevisStatut = async (id: string, statut: Devis['fields']['Statut']) => {
  const url = `${AIRTABLE_API_URL}/Devis/records`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ records: [{ id, fields: { Statut: statut } }] }),
  });
  if (!res.ok) {
    throw new Error('Erreur lors de la mise à jour du statut du devis');
  }
  const data = await res.json();
  return data.records[0];
};

export const incrementDevisOuvertures = async (id: string) => {
  const url = `${AIRTABLE_API_URL}/Devis/records`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ records: [{ id, fields: { Ouvertures: 1 } }] }),
  });
  if (!res.ok) {
    throw new Error('Erreur lors de l\'incrémentation des ouvertures');
  }
  const data = await res.json();
  return data.records[0];
};

export { getProduits }; 