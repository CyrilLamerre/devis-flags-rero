import { useState, useEffect } from 'react'
import { type Produit } from '../services/airtable'

interface LignePanier {
  produit: Produit
  quantite: number
}

export default function Panier() {
  const [lignes, setLignes] = useState<LignePanier[]>([])

  useEffect(() => {
    const handleAjouterProduit = (event: CustomEvent<Produit>) => {
      ajouterProduit(event.detail)
    }

    window.addEventListener('ajouterProduit', handleAjouterProduit as EventListener)
    return () => {
      window.removeEventListener('ajouterProduit', handleAjouterProduit as EventListener)
    }
  }, [])

  const ajouterProduit = (produit: Produit) => {
    setLignes((prev) => {
      const ligneExistante = prev.find((l) => l.produit.id === produit.id)
      if (ligneExistante) {
        return prev.map((l) =>
          l.produit.id === produit.id
            ? { ...l, quantite: l.quantite + 1 }
            : l
        )
      }
      return [...prev, { produit, quantite: 1 }]
    })
  }

  const modifierQuantite = (produitId: string, nouvelleQuantite: number) => {
    if (nouvelleQuantite < 1) {
      setLignes((prev) => prev.filter((l) => l.produit.id !== produitId))
      return
    }
    setLignes((prev) =>
      prev.map((l) =>
        l.produit.id === produitId ? { ...l, quantite: nouvelleQuantite } : l
      )
    )
  }

  const total = lignes.reduce(
    (acc, ligne) => acc + ligne.produit.fields['Prix TTC (€)'] * ligne.quantite,
    0
  )

  return (
    <div className="fixed right-0 top-0 w-80 bg-white p-6 rounded-xl shadow-lg">
      <h2 className="text-2xl font-semibold mb-4">Votre panier</h2>
      {lignes.length === 0 ? (
        <p className="text-gray-500">Votre panier est vide</p>
      ) : (
        <div className="space-y-4">
          {lignes.map((ligne) => (
            <div key={ligne.produit.id} className="border-b pb-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium">{ligne.produit.fields['Nom complet']}</h3>
                  <p className="text-sm text-gray-500">
                    {ligne.produit.fields['Prix TTC (€)']}€/unité
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => modifierQuantite(ligne.produit.id, ligne.quantite - 1)}
                    className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200"
                  >
                    -
                  </button>
                  <span>{ligne.quantite}</span>
                  <button
                    onClick={() => modifierQuantite(ligne.produit.id, ligne.quantite + 1)}
                    className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200"
                  >
                    +
                  </button>
                </div>
              </div>
              <div className="text-right mt-2">
                <span className="font-medium">
                  {(ligne.produit.fields['Prix TTC (€)'] * ligne.quantite).toFixed(2)}€
                </span>
              </div>
            </div>
          ))}
          <div className="border-t pt-4">
            <div className="flex justify-between items-center">
              <span className="font-semibold">Total TTC</span>
              <span className="text-xl font-bold text-accent">{total.toFixed(2)}€</span>
            </div>
            <button className="w-full mt-4 bg-primary text-white py-2 rounded-lg hover:bg-opacity-90">
              Passer au formulaire
            </button>
          </div>
        </div>
      )}
    </div>
  )
} 