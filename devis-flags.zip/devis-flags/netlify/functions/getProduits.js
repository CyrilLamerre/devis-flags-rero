const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

exports.handler = async function(event, context) {
  const apiKey = process.env.VITE_AIRTABLE_API_KEY;
  const baseId = process.env.VITE_AIRTABLE_BASE_ID;
  const AIRTABLE_API_URL = `https://api.airtable.com/v1/bases/${baseId}/tables/Produits/records`;

  const res = await fetch(AIRTABLE_API_URL, {
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
  });

  if (!res.ok) {
    return {
      statusCode: res.status,
      body: JSON.stringify({ error: 'Airtable API error', status: res.status }),
    };
  }

  const data = await res.json();
  return {
    statusCode: 200,
    body: JSON.stringify(data.records),
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
    },
  };
};